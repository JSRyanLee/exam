//dependencies
const express = require("express")
const mysql = require('mysql')
const jwt = require('jsonwebtoken')
const bcrypt = require("bcryptjs")

const app = express()
require("dotenv").config()

const db = mysql.createConnection({ // I am using variables stored in ./.env to make sure that there is no sensitive data left in the code. this will be excluded in a .gitignore file.
    host: process.env.DATABASE_HOST,
    user: process.env.DATABASE_USER,
    password: process.env.DATABASE_PASSWORD,
    database: process.env.DATABASE
})

exports.register = (req, res) => { // export the register page
    console.log(req.body);

    //declare the names of the items that will be submitted to the database

    const name = req.body.name;
    const email = req.body.email;
    const password = req.body.password;
    const passwordconfirm = req.body.passwordconfirm;



    //this is what actually enters users into the database after it validates that the email is not in use

    db.query("SELECT email FROM auth WHERE email = ?", [email], async (err, results) => {

        if (err) {
            console.log(err);

        }
        if (results.length > 0) { //check to see if there is already an email in use by comparing the amount of times it appears in the database
            return res.render("register.hbs", {
                message: "that email is already in use"
            });
        } else if (password !== passwordconfirm) { //confirm passwords by checking if they are not the same
            return res.render("register.hbs", {
                message: "passwords do not match"
            });
        }
        var hashedpassword = await bcrypt.hash(password, 8)
        // console.log(hashedpassword)




        db.query("INSERT INTO auth SET ?", {
            username: name,
            email: email,
            password: hashedpassword
        }, (err, results) => {
            if (err) {
                console.log(err)
            } else {
                console.log(results)
                return res.render("register.hbs", {
                    message: "user registered"
                });
            }
        }) // inserts details into the database

    });

}



exports.login = (req, res) => { // export the login page 
    console.log(req.body);
    

    const email = req.body.email
    const password = req.body.password

    const user = {
        name: email
    }

    const accessToken = jwt.sign(user, process.env.AccessTokenSecret)
    const authHeader = req.headers["authorization"]
    const token = authHeader && authHeader.split(" ")[1]
    jwt.verify(token, process.env.AccessTokenSecret, (err, user) => {
        if (err) res.sendStatus(403) // send error code
        req.user = user
        
    })
    //makes a copy of the token and splits it, taking the second half using the 1 index
    

    jwt.verify(token, process.env.AccessTokenSecret, (err, user) => {
        if (err) res.sendStatus(403) // send error code
        req.user = user
        
    })
    //signs the token with the secret
    
    //declare the names of the items that will checked by database
    //sql statement checks to see if the details match
    db.query('SELECT email FROM auth WHERE email = ? AND password = ?', {
        email: email,
        password: password
    }, async (err, results) => {
        var hashedpassword = await bcrypt.hash(password, 8) //hash password with 8 rounds of salt 

        const validpass = bcrypt.compare(password, hashedpassword, function(result) { // compare using the bcrypt middleware
            if (result) {
                console.log(err)
            } else {
                console.log("all good")

                

                return validpass
                //checks the hashed pasword and inputted password match
            }
        })


        if (results != 0) { //checks if the results is not equal to 0, and allows entry if it is so.


            return res.render("login.hbs", { //if the results are same, send the specified page
                message: "success"
            });

        } else {
            console.log("invalid password")
        } // error message
    });



}





// const posts = [{
    //     username: "ry@ry.com",
    //     title: "post1"
    // }]



    // app.get("/login", (req, res)=>{
    //     res.json(posts)
    // })
