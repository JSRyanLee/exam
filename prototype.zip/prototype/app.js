
//dependencies
const express = require('express');
const path = require('path');
const dotenv = require("dotenv")
const mysql = require("mysql")
const upload = require("express-fileupload") // declare dependencies and set app to express
// var cookieParser = require('cookie-parser'); cookie parser is deprecated and is not a dependency
dotenv.config({ path: "./.env"}) 


var app = express();


//create the connection to the database
const db = mysql.createConnection({
  host: process.env.DATABASE_HOST,
  user: process.env.DATABASE_USER,
  password: process.env.DATABASE_PASSWORD,
  database: process.env.DATABASE
// I am using variables stored in ./.env to make sure that there is no sensitive data left in the code. this will be excluded in a .gitignore file.
})
// try the connection to the database
db.connect( (err)=>{ 
  if (err){
    console.log(err)

  }else{
    console.log("connected to database successfully")
  }
})


app.set("view engine", "hbs")






//the routes must be above the parsing or it will encounter fatal errors and crash

//parse url-encoded bodies ( as sent by html forms)

app.use(express.urlencoded({ extended: false}));

//parse json bodies ( as sent by api clients)

app.use(express.json());

//define routes and reference their directories

app.use("/", require("./routes/pages.js"));

app.use("/auth", require("./routes/auth"));


var publicpath = path.join(__dirname, '/public')
app.use(express.static(publicpath));


app.use(upload()) // upload function is from the express-fileupload middleware

app.get("/resources", (req, res)=>{
    res.sendFile(__dirname + "/resources.hbs") //make a get route for sendign the filess
})

app.post("/resources", (req, res)=>{ 
    if (req.files){
        console.log(req.files)
        var file = req.files.file
        var filename = file.name // variables for referencing the file names
        console.log(filename)
        file.mv("./uploads" + filename, function(err){ //file.mv moves the file into the specified directory
          if (err){ console.log(err)} // check if theres an error before moving on
          else{console.log("file uploaded")}
        })
    }
})

// sets the port to 3000S
app.listen(3000, function() {
    console.log('Node app is running on port 3000');
});
