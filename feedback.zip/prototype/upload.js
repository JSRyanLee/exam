const express = require("express")
const upload = require("express-fileupload") // declare dependencies and set app to express
const app = express()


app.use(upload()) // upload function is from the express-fileupload middleware

app.get("/resources", (req, res)=>{
    res.sendFile(__dirname + "/resources.hbs") //make a get route for sendign the file
})

app.post("/resources", (req, res)=>{
    if (req.files){
        console.log(req.files)
    }
})