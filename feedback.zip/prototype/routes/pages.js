const express = require("express")
const router = express.Router()

router.get("/", (req, res)=>{
    res.render('home.hbs');
})
router.get("/register", (req, res)=>{
    res.render('register.hbs');
})
router.get("/login", (req, res)=>{
    res.render('login.hbs');
})
router.get("/resources", (req, res)=>{
    res.render('resources.hbs');
})
router.get("/monitoring", (req, res)=>{
    res.render('monitoring.hbs');
})
router.get("/account", (req, res)=>{
    res.render('account.hbs');
})
router.get("/resources", (req, res)=>{
    res.render('resources.hbs');
})
router.get("/management", (req, res)=>{
    res.render("management.hbs");
})
router.get("/contact", (req, res)=>{
    res.render("contact.hbs");
})

module.exports = router;